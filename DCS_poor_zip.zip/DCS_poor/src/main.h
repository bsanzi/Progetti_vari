#include<config.h>

#define MODE wifi

Adafruit_BME280 sBarometer;
